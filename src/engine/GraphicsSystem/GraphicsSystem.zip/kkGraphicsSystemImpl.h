﻿// SPDX-License-Identifier: GPL-3.0-only
#ifndef __KK_GS_H__
#define __KK_GS_H__

#include "GraphicsSystem/kkGraphicsSystem.h"
#include "Window/kkWindow.h"

#include "kkOpenGL.h"

struct ImGuiContext;

class kkGraphicsSystemImpl : public kkGraphicsSystem
{
	kkOpenGL * m_open_gl = nullptr;

public:

	kkGraphicsSystemImpl();
	virtual ~kkGraphicsSystemImpl();

	void setActive();

	bool initGS( kkWindow* output_window, const v2i& back_buffer_size, kk32u color_depth );

	void beginDraw( bool clear_canvas );
	void endDraw();
	void update();
	void setViewport( kk32 x, kk32 y, kk32 w, kk32 h );
	void drawRectangle( const v2i& c1, const v2i& c2, const kkColor& color1, const kkColor& color2, kkShader * shader = nullptr );
	void drawLine2D( const v2i& p1, const v2i& p2, const kkColor& color, kkShader * shader = nullptr );
	void drawLine3D( const kkVector4& p1, const kkVector4& p2, const kkColor& color, kkShader * shader = nullptr );
	kkMesh* createMesh(kkSMesh*, kkMeshType);
	void drawMesh(kkMesh*, const kkMatrix4& W, kkShader * shader = nullptr);
	kkTexture* createTexture(kkImage*);
	bool createShader( kkShader* out_shader, const char * v, const char * v_main, const char * f, const char * f_main );
	void setClearColor( const kkColor& c );
	void setActiveCamera( kkCamera * c );
	void useDepth( bool );
	void useScissor( bool );
	void setScissor( int x1, int y1, int x2, int y2 );
};


#endif