﻿// SPDX-License-Identifier: GPL-3.0-only
#ifndef __KK_OPENGL_TEXTURE_H__
#define __KK_OPENGL_TEXTURE_H__

#include "GraphicsSystem/kkTexture.h"

class kkOpenGLTexture : public kkTexture
{
	GLuint m_texture   = 0;

	friend class kkOpenGL;
public:
	kkOpenGLTexture();
	virtual ~kkOpenGLTexture();

	bool init(kkImage*);

	void* getHandle();

};


#endif