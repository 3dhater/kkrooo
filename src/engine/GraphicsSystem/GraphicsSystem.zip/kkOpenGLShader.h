﻿// SPDX-License-Identifier: GPL-3.0-only
#ifndef __KK_OPENGL_SHADER_H__
#define __KK_OPENGL_SHADER_H__

#include <GL/gl3w.h>

#include "Classes/Containers/kkArray.h"
#include "Classes/Containers/kkPair.h"
#include "Classes/Strings/kkString.h"

class kkOpenGLShader : public kkShader
{
	
	GLuint m_program = 0;

	kkArray<kkPair<GLuint,kkStringA>> m_uniforms;

public:
	kkOpenGLShader();
	virtual ~kkOpenGLShader();

	bool create(const char * vert, const char * frag);

	void onShader( void * ptr, const kkMatrix4& world );
	void onCreate( void * ptr );
	void setActive();

	void addUniform(const char*);

	GLuint getUniform(kk32u);
	GLuint getProgram();


	static GLuint _createShaderProgram(GLuint v, GLuint f);
	static GLuint _createShader(GLenum type, const char * text);
	static bool _checkShader(kk32u shader);
	static bool _checkProgram(kk32u program);
};

#endif