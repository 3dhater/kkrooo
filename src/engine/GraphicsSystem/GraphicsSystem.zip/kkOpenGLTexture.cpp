﻿// SPDX-License-Identifier: GPL-3.0-only
#define KK_EXPORTS
#include "kkrooo.engine.h"

#include <GL/gl3w.h>

#include "kkOpenGLTexture.h"

kkOpenGLTexture::kkOpenGLTexture()
{
}


kkOpenGLTexture::~kkOpenGLTexture()
{
	if( m_texture ) glDeleteTextures(1, &m_texture);
}

bool kkOpenGLTexture::init(kkImage* i)
{
	auto & info = this->getInfo();
	info = *i;

	glGenTextures(1, &m_texture);
    glBindTexture(GL_TEXTURE_2D, m_texture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, info.m_width, info.m_height, 0, GL_BGRA, GL_UNSIGNED_BYTE, info.m_data8);
	
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    
	// info содержит только информацию
	info.m_data8  = nullptr;
	info.m_data16 = nullptr;
	info.m_data32 = nullptr;
	info.m_data64 = nullptr;

	return true;
}

void* kkOpenGLTexture::getHandle()
{
	return (void*)&m_texture;
}
